package PatronesNumericos;

import java.util.Scanner;

public class PatronesNumericos {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Ingrese numero entero positivo");
		int n = sc.nextInt();
 if (n<= 0) {
	 System.out.println("Error: el numero debe ser positivo");
	 return;
	 
 }
	
 System.out.println("Patron 1: Triangulo ascendente");
 Triangulo(n);
		
 System.out.println("Patron 2: Triangulo descendente");
 Triangulodescendente(n);
 
 System.out.println("Patron 3: Piramide asteriscos");
  if (n % 2 == 0) {
	  System.out.println("Piramide se genera si el numero es impar");
  } 
  else { 
	  piramide(n);
	  
  }
  sc.close();
	}
	
	public static void Triangulo(int n) {
		for (int i = 1; i <= n; i++) { 
			for (int j = 1; j <= i; j++) {
				System.out.print(j);
				
			}
			System.out.println();
			
		}
	}
	public static void Triangulodescendente(int n) {
		for (int i = n; i>= 1; i--) { 
			for (int j = 1; j<= i; j++) {
				System.out.print(j);
			}
			System.out.println();
		}
	}
	
	public static void	piramide(int n) {
		int filas=(n/2) +1;
		
		for (int i = 1; i<= filas; i++) {
			
			for (int j=1; j<= filas - i; j++) {
				System.out.print(" ");
			}
			for ( int k = 1; k<= (2 *i - 1 ); k++) {
				System.out.print("*");
				
			}
			System.out.println();
		}
		
		}
	}
	

